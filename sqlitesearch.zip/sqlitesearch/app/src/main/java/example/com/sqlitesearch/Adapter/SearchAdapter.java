package example.com.sqlitesearch.Adapter;


import android.content.Context;
import android.support.annotation.NonNull;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import java.util.List;

import example.com.sqlitesearch.R;
import example.com.sqlitesearch.model.Big_Song_Book;

import static example.com.sqlitesearch.R.id.NUMBER;
import static example.com.sqlitesearch.R.id.layout_item;

class SearchViewHolder extends RecyclerView.ViewHolder {

    public TextView NUMBER, SONG_TITLE, SONG_WORDS;

    public SearchViewHolder(@NonNull View itemView) {
        super(itemView);

        NUMBER = (TextView) itemView.findViewById(R.id.NUMBER);
        SONG_TITLE = (TextView) itemView.findViewById(R.id.SONG_TITLE);
        SONG_WORDS = (TextView) itemView.findViewById(R.id.SONG_WORDS);




    }
}

public class SearchAdapter extends RecyclerView.Adapter<SearchViewHolder> {
    private  Context context;

//need checking for clarifying
    private List<Big_Song_Book> big_song_books;


    public SearchAdapter(Context context, List<Big_Song_Book> big_song_books) {
        this.context = context;
        this.big_song_books = big_song_books;
    }

    @NonNull
    @Override
    public SearchViewHolder onCreateViewHolder(@NonNull ViewGroup viewGroup, int i) {

        LayoutInflater inflater= LayoutInflater.from(viewGroup.getContext());
        View itemView =inflater.inflate(R.id.layout_item, viewGroup, false);



        return new SearchViewHolder(itemView);
    }

    @Override
    public void onBindViewHolder(@NonNull SearchViewHolder searchViewHolder, int i) {

        searchViewHolder.NUMBER.setText(Big_Song_Book.get(position).getNUMBER());
        searchViewHolder.SONG_TITLE.setText(Big_Song_Book.get(position).getSONG_TITLE());
        searchViewHolder.SONG_WORDS.setText(Big_Song_Book.get(position).getSONG_WORDS());
       // holder.NUMBER

    }

    @Override
    public int getItemCount() {
        return  big_song_books.size();
    }
}
