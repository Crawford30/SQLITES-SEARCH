package example.com.sqlitesearch.Database;

import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteQueryBuilder;
import android.widget.CursorAdapter;

import com.readystatesoftware.sqliteasset.SQLiteAssetHelper;

import java.util.ArrayList;
import java.util.List;

import example.com.sqlitesearch.model.Big_Song_Book;

public class Database extends SQLiteAssetHelper {


    private static final String DB_NAME = "BIG_SONG_BOOK_DB.db";
    private static final int DB_VER = 1;


    public Database(Context context) {
        super(context, DB_NAME, null, DB_VER);
    }

    //function get all BIG_SONG_BOOK_DB
    public List<Big_Song_Book> getBIG_SONG_BOOK_TABLE(){

    //public List<Big_Song_Book> getBig_Song_Book()// {
        SQLiteDatabase db = getReadableDatabase();
        SQLiteQueryBuilder qb = new SQLiteQueryBuilder();

        String[] sqlselect = {"NUMBER", "SONG_TITLE", "SONG_WORDS"};
        String tableName = "BIG_SONG_BOOK_TABLE";

        qb.setTables(tableName);

        Cursor cursor = qb.query(db, sqlselect, null, null, null, null, null);
        List<Big_Song_Book> result = new ArrayList<>();

        if (((Cursor) cursor).moveToFirst()) {
            do {
                Big_Song_Book big_song_book = new Big_Song_Book();
                big_song_book.setNUMBER(cursor.getString(cursor.getColumnIndex("NUMBER"))); //DATABASE ISSUE
                big_song_book.setSONG_TITLE(cursor.getString(cursor.getColumnIndex("SONG_TITLE")));
                big_song_book.setSONG_WORDS(cursor.getString(cursor.getColumnIndex("SONG_WORDS")));

                result.add(big_song_book);
            }
            while (cursor.moveToNext());
        }
        return result;

    }


//function to get all number

    public List<String> getSONG_TITLES() {

        SQLiteDatabase db = getReadableDatabase();
        SQLiteQueryBuilder qb = new SQLiteQueryBuilder();

        String[] sqlselect = {"SONG_TITLE"};
        String tableName = "BIG_SONG_BOOK_TABLE";

        qb.setTables(tableName);
        Cursor cursor = qb.query(db, sqlselect, null, null, null, null, null);
        List<String> result = new ArrayList<>();

        if (((Cursor) cursor).moveToFirst()) {
            do {
                result.add(cursor.getString(cursor.getColumnIndex("SONG_TITLE")));
            } while (cursor.moveToNext());
        }
        return result;


    }


    public List<Big_Song_Book>getsongbyname(String SONG_WORDS){

        SQLiteDatabase db = getReadableDatabase();
        SQLiteQueryBuilder qb = new SQLiteQueryBuilder();

        String[] sqlselect = {"SONG_WORDS"};
        String tableName = "BIG_SONG_BOOK_TABLE";

        qb.setTables(tableName);
        Cursor cursor = qb.query(db, sqlselect, "SONG_WORDS LIKE ?", new String[]{"%"+SONG_WORDS+"%"}, null, null, null);
        List<String> result = new ArrayList<>();

        if (((Cursor) cursor).moveToFirst()) {
            do {
                result.add(cursor.getString(cursor.getColumnIndex("SONG_WORDS")));
            } while (cursor.moveToNext());
        }
        return result;




    }

}

//}//